import java.net.*;
import java.io.*;
import java.util.*;

public class GameServer {
	  public static int port =8888;
	  
	  //Random win game number
	  public static Random rand = new Random();
	  public static int ans = rand.nextInt(999)+1;
	  
	  //Player number
	  public int player = 0;
	  public int playerNum = 0;

	public GameServer () throws IOException {
		System.out.println("The target is :" + ans);
		System.out.println("Waiting for the first players");
		ServerSocket server = new ServerSocket (port);
		while (true) {
			Socket client = server.accept();
			DataInputStream in = new DataInputStream(client.getInputStream());
			String name = "Player" + String.valueOf(player);
			player++;
			playerNum++;
			
			System.out.println ("\n***************************************************");
			System.out.println ("One player " + name + " has inside this gameroom" );
			System.out.println ("Current total player: " + playerNum);
			System.out.println ("***************************************************\n");

			
			GamePlay c = new GamePlay (name, client, ans);
			c.start ();
		}
	}

	public static void main (String args[]) throws IOException {

      new GameServer();
	}
}

