import java.net.*;
import java.io.*;
import java.util.*;
import java.lang.*;

public class GamePlay extends Thread {
	//Socket//
	private Socket socket;
	private DataInputStream in;
	private DataOutputStream out;
	//GamePlay: Player name, answer, current turn player//
	public String name;
	public int ans;
	public int cPlayer ,playerNum;
	public static int cTurn=0;
	//Communication with Player
	protected static Vector handlers = new Vector( );
	protected boolean isSend = false;
	//Check answer (Hits)
	int higher = 999, lower = 1;

   public GamePlay (String name, Socket socket, int ans) throws IOException {
		this.name = name;
		this.socket = socket;
		this.ans = ans;
		in = new DataInputStream (
		  new BufferedInputStream(socket.getInputStream()));
		out = new DataOutputStream (
		  new BufferedOutputStream (socket.getOutputStream()));
   }

   public  synchronized void  run() {
		try {
			
			cPlayer=handlers.size();
			playerNum=handlers.size();
			//save Vector location
			handlers.addElement(this);
			
			sendmessage(playerNum, "--------------------------------------------------");
			sendmessage(playerNum, name +" joined"); 
			sendmessage(playerNum, "--------------------------------------------------\n");
	
	
			while (true) {
				//Check the turn is/not the player
				if( isSend == false && cPlayer == cTurn){
					String msg = new String("Your turn now:");
					sendmessage(cTurn, msg);
					isSend = true;
					}
					
				//Get Player input
				String message = in.readUTF();
				int n = Integer.parseInt(message);
				System.out.println( name + " guess :: " + message);
				//Check answer
				if(Integer.parseInt(message) > ans){
					String msg="Too High!";
					sendmessage(cTurn, msg);
					hits(n);
					line();
				}else if(Integer.parseInt(message) < ans){
					String msg="Too Low!";
					sendmessage(cTurn, msg);
					hits(n);
					line();
				}else if(Integer.parseInt(message) == ans){
					System.out.println("Player "+cTurn+" win!");
					System.out.println("Game over! ");
					String msg="You win!!";
					sendmessage(cTurn, msg);
					line();
					for(int i = 0; i < handlers.size(); i++){
						if(i != cTurn){
						String ggMsg="Game Over,you lose";
						sendmessage(i, ggMsg);
						}
					}
					closeServer();
					continue;
				}
				cTurn++;
				//Make sure turn is exist
				if (cTurn >= handlers.size())
					cTurn = 0;
				
				System.out.println("Next Player::" + cTurn);
				// Tmessage=new String("Your turn now:");
				cPlayer = cTurn;
				isSend=false;
			}
		} catch (Exception ex) {} 
		finally{
			handlers.removeElement (this);
			for(int i = 0; i < handlers.size(); i++){
				String disC="Disconnected";
				sendmessage(i, disC);
				closeServer();
			}

			closeServer();
	
			try {
				socket.close ();
			} catch (IOException ex) {
				System.out.println("Did user Socket closed?");
			}
      }
   }
	
	public void hits(int in){
		if(in > lower && in < ans){
			lower = in;
		}else if(in > ans && in < higher){
			higher = in;
		}
		String hitss = "Hits: The range is about " + lower + " ~ " + higher;
		sendmessage(cTurn, hitss);
	}
	
	public void line(){
		String lineMsg="--------------------------------------------------\n";
		sendmessage(cTurn, lineMsg);
	}


   protected static void broadcast (String message) {
      synchronized (handlers) {
         Enumeration e = handlers.elements ();
         while (e.hasMoreElements ()) {
            GamePlay handler = (GamePlay) e.nextElement ();
            try {
               handler.out.writeUTF (message);
               handler.out.flush ();
            } catch (Exception ex) {
               handler.stop ();
            }
         }
      }

}
	protected void closeServer(){
		try{
			socket.close();
		}catch(Exception e){}
	}

	protected static void sendmessage(int cTurn,String Tmessage){
        GamePlay handler = (GamePlay) handlers.elementAt(cTurn);
        try {
            handler.out.writeUTF (Tmessage);
			//System.out.println("send message to "+cTurn);
            handler.out.flush ();
        } catch (Exception ex) {
            handler.stop ();
		}


	}
}
