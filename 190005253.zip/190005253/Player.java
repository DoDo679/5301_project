import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Player {

   private Socket socket;
   protected static int port=8888;
   private DataInputStream in;
   private DataOutputStream out;
   
   private String turn, record;
   private InetAddress server;
   
   public boolean myTurn=false;
   public String quit = "quit";


   public Player(){

      try {
		 server = InetAddress.getLocalHost();
         socket = new Socket(server, port);
         in = new DataInputStream(socket.getInputStream());
         out = new DataOutputStream(socket.getOutputStream());


         String ee="Your turn now:";
         String gg="Game Over,you lose";


         while (true) {

			String reply = in.readUTF();

      String [] result = reply.split("\n");
      for(int i = 0; i < result.length; i++){
	  System.out.println(result[i]);
      if(result[i].compareTo(ee)==0){myTurn =true;}
      if(result[i].compareTo(gg)==0){disconnect();}
  }

	while(myTurn==true){
		Scanner sc = new Scanner(System.in);
		String i = sc.nextLine();
		
		sendTextToChat(i);

  //System.out.print("send");

							}
}





      }	catch (Exception e)	{
		  disconnect();
		  }
   }

   protected void sendTextToChat(String str) {



		  try{

		  if(Integer.parseInt(str)>0&&Integer.parseInt(str)<1000){
         out.writeUTF(str);
         myTurn=false;
        // System.out.println("send");
	 }



      }catch (Exception e) {
		  if(str.compareTo(quit)==0){
      disconnect();}
      else{
		  System.out.println("Please input a number between 1 to 999");
		  System.out.println(myTurn);
		  		 myTurn= true;

		  }
      }
   }


   protected void disconnect() {
      try {
		  myTurn= false;
         socket.close();
      } catch (IOException e) {  }
   }

   public static void main (String args[])throws IOException {

      Player c = new Player();
   }
}



